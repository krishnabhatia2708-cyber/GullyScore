import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Share2, Download, Trophy, Users, Target } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { supabase } from '../lib/supabase';
import { Match, Ball, Player } from '../types';
import { TopBar } from '../components/layout/TopBar';
import { Spinner } from '../components/ui/Spinner';
import { showToast } from '../components/ui/Toast';

interface BatsmanStats {
  playerId: string;
  playerName: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  out: boolean;
  dismissalType?: string;
  bowlerName?: string;
  fielderName?: string;
}

interface BowlerStats {
  playerId: string;
  playerName: string;
  overs: number;
  balls: number;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
}

interface FallOfWicket {
  wicketNum: number;
  score: number;
  overs: string;
  batsman: string;
}

export function ScorecardPage() {
  const { params, navigate } = useApp();
  const matchId = params?.matchId;
  const [match, setMatch] = useState<Match | null>(null);
  const [balls, setBalls] = useState<Ball[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeInnings, setActiveInnings] = useState(1);

  useEffect(() => {
    if (matchId) loadData();
  }, [matchId]);

  const loadData = async () => {
    setLoading(true);
    const [matchRes, ballsRes] = await Promise.all([
      supabase.from('matches').select('*').eq('id', matchId).single(),
      supabase.from('balls').select('*').eq('match_id', matchId).order('created_at', { ascending: true }),
    ]);

    if (matchRes.data) setMatch(matchRes.data);
    if (ballsRes.data) setBalls(ballsRes.data);

    // Load player names
    const playerIds = new Set<string>();
    ballsRes.data?.forEach(b => {
      if (b.striker_id) playerIds.add(b.striker_id);
      if (b.bowler_id) playerIds.add(b.bowler_id);
      if (b.fielder_id) playerIds.add(b.fielder_id);
    });
    if (playerIds.size > 0) {
      const playersRes = await supabase.from('players').select('*').in('id', Array.from(playerIds));
      if (playersRes.data) setPlayers(playersRes.data);
    }
    setLoading(false);
  };

  const getPlayerName = (playerId: string | null) => {
    if (!playerId) return 'Unknown';
    const p = players.find(p => p.id === playerId);
    return p?.name || 'Unknown';
  };

  const calculateBatsmanStats = (innings: number): BatsmanStats[] => {
    const stats: Map<string, BatsmanStats> = new Map();
    const inningsBalls = balls.filter(b => b.innings === innings);

    inningsBalls.forEach(ball => {
      if (!ball.striker_id) return;
      let s = stats.get(ball.striker_id);
      if (!s) {
        s = {
          playerId: ball.striker_id,
          playerName: getPlayerName(ball.striker_id),
          runs: 0,
          balls: 0,
          fours: 0,
          sixes: 0,
          out: false,
        };
        stats.set(ball.striker_id, s);
      }

      if (ball.wicket && ball.dismissal_type !== 'RUN_OUT_OTHER') {
        s.out = true;
        s.dismissalType = ball.dismissal_type || '';
        s.bowlerName = getPlayerName(ball.bowler_id);
        s.fielderName = ball.fielder_id ? getPlayerName(ball.fielder_id) : undefined;
      } else if (!ball.is_extra || ball.extra_type === 'BYES' || ball.extra_type === 'LEG_BYE') {
        s.balls++;
        if (!ball.is_extra) {
          s.runs += ball.runs;
          if (ball.runs === 4) s.fours++;
          if (ball.runs === 6) s.sixes++;
        }
      }
    });

    return Array.from(stats.values()).sort((a, b) => b.runs - a.runs);
  };

  const calculateBowlerStats = (innings: number): BowlerStats[] => {
    const stats: Map<string, BowlerStats> = new Map();
    const inningsBalls = balls.filter(b => b.innings === innings);

    inningsBalls.forEach(ball => {
      if (!ball.bowler_id) return;
      let s = stats.get(ball.bowler_id);
      if (!s) {
        s = {
          playerId: ball.bowler_id,
          playerName: getPlayerName(ball.bowler_id),
          overs: 0,
          balls: 0,
          maidens: 0,
          runs: 0,
          wickets: 0,
          economy: 0,
        };
        stats.set(ball.bowler_id, s);
      }

      s.balls++;
      if (!ball.is_extra || ball.extra_type === 'BYES' || ball.extra_type === 'LEG_BYE') {
        s.runs += ball.runs;
      } else if (ball.extra_type === 'WIDE' || ball.extra_type === 'NO_BALL') {
        s.runs += 1;
      }

      if (ball.wicket && !['RUN_OUT_OTHER', 'RUN_OUT_STRIKER'].includes(ball.dismissal_type || '')) {
        s.wickets++;
      }
    });

    // Calculate overs and maidens
    stats.forEach(s => {
      s.overs = Math.floor(s.balls / 6);
      const rem = s.balls % 6;
      s.economy = s.overs > 0 ? Number((s.runs / (s.balls / 6)).toFixed(2)) : 0;
    });

    return Array.from(stats.values()).sort((a, b) => a.runs - b.runs);
  };

  const getFallOfWickets = (innings: number): FallOfWicket[] => {
    const fow: FallOfWicket[] = [];
    const inningsBalls = balls.filter(b => b.innings === innings && b.wicket);

    inningsBalls.forEach((ball, idx) => {
      if (!ball.striker_id) return;
      const ballsUpToWicket = inningsBalls.filter(b => {
        const ballIdx = inningsBalls.indexOf(b);
        return ballIdx <= inningsBalls.indexOf(ball);
      });
      const totalRuns = ballsUpToWicket.reduce((sum, b) => sum + (b.is_extra && ['WIDE', 'NO_BALL'].includes(b.extra_type || '') ? b.runs + 1 : b.runs), 0);
      const totalBalls = ballsUpToWicket.length;
      const overs = `${Math.floor(totalBalls / 6)}.${totalBalls % 6}`;

      fow.push({
        wicketNum: idx + 1,
        score: totalRuns,
        overs,
        batsman: getPlayerName(ball.striker_id),
      });
    });

    return fow;
  };

  const getPartnerships = (innings: number): { runs: number; overs: string; batsmen: string[] }[] => {
    // Simplified partnership calculation
    const inningsBalls = balls.filter(b => b.innings === innings);
    return [];
  };

  const formatDismissal = (stats: BatsmanStats): string => {
    if (!stats.out) return 'not out';
    const type = stats.dismissalType?.replace(/_/g, ' ').toLowerCase() || 'out';
    if (type === 'bowled') return `b ${stats.bowlerName}`;
    if (type === 'caught') return `c ${stats.fielderName || ' Unknown'} b ${stats.bowlerName}`;
    if (type === 'lbw') return `lbw b ${stats.bowlerName}`;
    if (type === 'run out') return `run out (${stats.fielderName || ' Unknown'})`;
    if (type === 'stumped') return `st ${stats.fielderName || ' Unknown'} b ${stats.bowlerName}`;
    return `${type} b ${stats.bowlerName}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950">
        <TopBar title="Scorecard" />
        <div className="flex justify-center py-20"><Spinner /></div>
      </div>
    );
  }

  if (!match) {
    return (
      <div className="min-h-screen bg-gray-950">
        <TopBar title="Scorecard" />
        <div className="px-4 py-20 text-center text-gray-500">Match not found</div>
      </div>
    );
  }

  const innings1Batting = calculateBatsmanStats(1);
  const innings1Bowling = calculateBowlerStats(1);
  const innings2Batting = calculateBatsmanStats(2);
  const innings2Bowling = calculateBowlerStats(2);
  const fow1 = getFallOfWickets(1);
  const fow2 = getFallOfWickets(2);

  return (
    <div className="min-h-screen bg-gray-950 pb-6">
      <TopBar title="Scorecard" showBack backTo="dashboard" />

      <div className="px-4 max-w-2xl mx-auto pt-4 space-y-4">
        {/* Match Header */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="gs-card-premium p-4">
          <div className="text-center mb-4">
            <div className="text-gray-500 text-sm">{match.venue || 'Gully Cricket Match'}</div>
            <div className="text-white font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              {match.team_a_name} vs {match.team_b_name}
            </div>
            <div className="text-gray-500 text-xs mt-1">{match.overs} Overs</div>
          </div>

          {/* Toss Info */}
          {match.toss_winner && (
            <div className="text-center mb-3 text-xs text-gray-400">
              {match.toss_winner} won the toss and chose to {match.toss_decision?.toLowerCase() || 'bat'}
            </div>
          )}

          {/* Result */}
          {match.result && (
            <div className="text-center py-3 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 rounded-xl border border-amber-500/30">
              <Trophy className="w-5 h-5 text-amber-500 mx-auto mb-1" />
              <div className="text-amber-400 font-bold text-sm">{match.result}</div>
              {match.player_of_match && (
                <div className="text-xs text-gray-300 mt-1">
                  Player of the Match: <span className="text-amber-400 font-semibold">{match.player_of_match}</span>
                </div>
              )}
            </div>
          )}

          {/* Score Summary */}
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="text-center p-3 bg-gray-900/50 rounded-xl">
              <div className="text-gray-500 text-xs mb-1">
                {match.innings === 1 ? match.team_a_name : match.team_b_name}
              </div>
              <div className="text-2xl font-black text-white" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                {match.score1}/{match.wickets1}
              </div>
              <div className="text-gray-500 text-xs">
                {Math.floor(match.balls1 / 6)}.{match.balls1 % 6} ov
              </div>
            </div>
            <div className="text-center p-3 bg-gray-900/50 rounded-xl">
              <div className="text-gray-500 text-xs mb-1">
                {match.innings === 1 ? match.team_b_name : match.team_a_name}
              </div>
              {match.innings >= 2 ? (
                <>
                  <div className="text-2xl font-black text-white" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                    {match.score2}/{match.wickets2}
                  </div>
                  <div className="text-gray-500 text-xs">
                    {Math.floor(match.balls2 / 6)}.{match.balls2 % 6} ov
                  </div>
                </>
              ) : (
                <div className="text-gray-600 text-sm">Yet to bat</div>
              )}
            </div>
          </div>

          {match.target && (
            <div className="text-center mt-3 text-amber-400 text-sm flex items-center justify-center gap-2">
              <Target className="w-4 h-4" />
              Target: {match.target}
            </div>
          )}

          {/* Match Duration */}
          {match.completed_at && match.created_at && (
            <div className="text-center mt-3 text-xs text-gray-500">
              Duration: {Math.round((new Date(match.completed_at).getTime() - new Date(match.created_at).getTime()) / 60000)} mins
            </div>
          )}
        </motion.div>

        {/* Innings Tabs */}
        {match.innings >= 2 && (
          <div className="flex bg-gray-900 rounded-xl p-1">
            {[1, 2].map(ing => (
              <button
                key={ing}
                onClick={() => setActiveInnings(ing)}
                className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${
                  activeInnings === ing ? 'bg-amber-500 text-black' : 'text-gray-400'
                }`}
              >
                {ing === 1 ? match.team_a_name : match.team_b_name} Innings
              </button>
            ))}
          </div>
        )}

        {/* Batting Scorecard */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="gs-card overflow-hidden">
          <div className="flex items-center gap-2 p-3 border-b border-gray-800">
            <Users className="w-4 h-4 text-emerald-500" />
            <span className="font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              Batting - {activeInnings === 1 ? match.team_a_name : match.team_b_name}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-500 text-xs bg-gray-900/50">
                  <th className="text-left p-2">Batsman</th>
                  <th className="text-center p-2">R</th>
                  <th className="text-center p-2">B</th>
                  <th className="text-center p-2">4s</th>
                  <th className="text-center p-2">6s</th>
                  <th className="text-right p-2">SR</th>
                </tr>
              </thead>
              <tbody>
                {(activeInnings === 1 ? innings1Batting : innings2Batting).map((player, idx) => (
                  <tr key={player.playerId} className="border-t border-gray-800/50">
                    <td className="p-2">
                      <div className="font-medium text-white">{player.playerName}</div>
                      <div className="text-xs text-gray-500">{formatDismissal(player)}</div>
                    </td>
                    <td className="text-center p-2 font-bold text-amber-500">{player.runs}</td>
                    <td className="text-center p-2 text-gray-400">{player.balls}</td>
                    <td className="text-center p-2 text-gray-400">{player.fours}</td>
                    <td className="text-center p-2 text-gray-400">{player.sixes}</td>
                    <td className="text-right p-2 text-gray-400">
                      {player.balls > 0 ? ((player.runs / player.balls) * 100).toFixed(1) : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Extras */}
          <div className="p-2 border-t border-gray-800/50 text-xs text-gray-500">
            Extras: {(activeInnings === 1
              ? balls.filter(b => b.innings === 1 && b.is_extra)
              : balls.filter(b => b.innings === 2 && b.is_extra)
            ).reduce((sum, b) => sum + (b.extra_type === 'WIDE' || b.extra_type === 'NO_BALL' ? 1 : 0) + (b.runs || 0), 0)}
          </div>
        </motion.div>

        {/* Bowling Scorecard */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="gs-card overflow-hidden">
          <div className="flex items-center gap-2 p-3 border-b border-gray-800">
            <Users className="w-4 h-4 text-blue-500" />
            <span className="font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              Bowling - {activeInnings === 1 ? match.team_b_name : match.team_a_name}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-500 text-xs bg-gray-900/50">
                  <th className="text-left p-2">Bowler</th>
                  <th className="text-center p-2">O</th>
                  <th className="text-center p-2">M</th>
                  <th className="text-center p-2">R</th>
                  <th className="text-center p-2">W</th>
                  <th className="text-right p-2">Econ</th>
                </tr>
              </thead>
              <tbody>
                {(activeInnings === 1 ? innings1Bowling : innings2Bowling).map((player) => (
                  <tr key={player.playerId} className="border-t border-gray-800/50">
                    <td className="p-2 font-medium text-white">{player.playerName}</td>
                    <td className="text-center p-2 text-gray-400">
                      {player.overs}.{player.balls % 6}
                    </td>
                    <td className="text-center p-2 text-gray-400">{player.maidens}</td>
                    <td className="text-center p-2 text-gray-400">{player.runs}</td>
                    <td className="text-center p-2 font-bold text-emerald-500">{player.wickets}</td>
                    <td className="text-right p-2 text-gray-400">{player.economy}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Fall of Wickets */}
        {(activeInnings === 1 ? fow1 : fow2).length > 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="gs-card p-3">
            <div className="font-bold mb-2" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Fall of Wickets</div>
            <div className="flex flex-wrap gap-2">
              {(activeInnings === 1 ? fow1 : fow2).map((w, idx) => (
                <span key={idx} className="text-xs bg-gray-800 px-2 py-1 rounded">
                  <span className="text-gray-500">{w.wicketNum}.</span>{' '}
                  <span className="text-white">{w.score}/{w.wicketNum}</span>{' '}
                  <span className="text-gray-500">({w.batsman}, {w.overs})</span>
                </span>
              ))}
            </div>
          </motion.div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <button
            onClick={() => {
              navigator.clipboard.writeText(`Scorecard: ${match.team_a_name} vs ${match.team_b_name}\n${match.score1}/${match.wickets1} vs ${match.score2}/${match.wickets2}`);
              showToast('Scorecard copied!', 'success');
            }}
            className="flex-1 gs-btn-secondary py-3 flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" /> Share
          </button>
          <button
            onClick={() => navigate('live-scoring', { matchId: match.id })}
            className="flex-1 gs-btn-primary py-3"
          >
            View Match
          </button>
        </div>
      </div>
    </div>
  );
}
